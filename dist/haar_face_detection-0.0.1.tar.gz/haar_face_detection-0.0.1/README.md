Haar face detection 
